NO_CONFIG = {'streams': [{'url': "#", 'title': "No configuration found"}]}
NO_RESULTS = {'streams': [{'url': "#", 'title': "No results found"}]}
JACKETT_ERROR = {'streams': [{'url': "#", 'title': "An error occured"}]}

CACHER_URL = "https://stremio-jackett-cacher.elfhosted.com/"
